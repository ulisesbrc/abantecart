<?php
/*------------------------------------------------------------------------------
  $Id$

  AbanteCart, Ideal OpenSource Ecommerce Solution
  http://www.AbanteCart.com

  Copyright © 2011-2020 Belavier Commerce LLC

  This source file is subject to Open Software License (OSL 3.0)
  License details is bundled with this package in the file LICENSE.txt.
  It is also available at this URL:
  <http://www.opensource.org/licenses/OSL-3.0>

 UPGRADE NOTE:
   Do not edit or add to this file if you wish to upgrade AbanteCart to newer
   versions in the future. If you wish to customize AbanteCart for your
   needs please refer to http://www.AbanteCart.com for more information.
------------------------------------------------------------------------------*/
if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}

/**
 * @property ModelExtensionBannerManager $model_extension_precio_manager
 */
class ControllerPagesExtensionPrecioManager extends AController
{
    public $data = array();
    public $error = array();

    public function main()
    {

        //init controller data
        $this->extensions->hk_InitData($this, __FUNCTION__);

        $this->loadLanguage('precio_manager/precio_manager');

        $this->document->setTitle($this->language->get('precio_manager_name'));
        $this->data['heading_title'] = $this->language->get('precio_manager_list');


        $this->document->initBreadcrumb(array(
            'href'      => $this->html->getSecureURL('index/home'),
            'text'      => $this->language->get('text_home'),
            'separator' => false,
        ));
         $this->document->addBreadcrumb(array(
            'href'      => $this->html->getSecureURL('extension/precio_manager'),
            'text'      => $this->language->get('precio_manager_name'),
            'separator' => ' :: ',
            'current'   => true,
        ));

        $this->loadModel('extension/precio_manager');
        $datos = $this->model_extension_precio_manager->getProduct();
        $this->view->batchAssign($this->language->getASet());
        $this->view->batchAssign($this->data);
        $this->view->assign('help_url', $this->gen_help_url('precio_manager'));
        $this->view->assign('data', $datos );
        $this->view->assign('url_actulizar', $this->html->getSecureURL('extension/precio_manager/actualizar', ''));
        $this->view->assign('url_actulizar_poduct', $this->html->getSecureURL('catalog/product/update', '')); 
        $this->view->assign('url_actulizar_array', $this->html->getSecureURL('extension/precio_manager/actualizar_array', ''));
        $this->processTemplate('pages/extension/precio_manager.tpl');
        //update controller data
        $this->extensions->hk_UpdateData($this, __FUNCTION__);
    }



    public function actualizar()
    {
        //init controller data
        $this->extensions->hk_InitData($this, __FUNCTION__);

        $product_id = (int)$this->request->get['product_id'];
        $porcentaje =floatval($this->request->get['porcentaje']);
      
        $this->loadModel('extension/precio_manager');
        $this->model_extension_precio_manager->actualizarProducto($product_id ,$porcentaje);
        //update controller data
        //$this->extensions->hk_UpdateData($this, __FUNCTION__);
        redirect($this->html->getSecureURL('extension/precio_manager'));
    }
    public function actualizar_array()
    {
        //init controller data
        $this->extensions->hk_InitData($this, __FUNCTION__);
        $array_porcentaje =$this->request->post['array_id_actualizar'];
        $porcentaje_global =$this->request->post['porcentaje_global']; 
        $selectall =$this->request->post['selectall']; 
        $porcentaje_global = floatval($porcentaje_global);    
        if(is_array($array_porcentaje) and !is_null($array_porcentaje)){
            $in = implode(",", $array_porcentaje);
            $this->loadModel('extension/precio_manager');
            $this->model_extension_precio_manager->actualizarArrayProducto($in ,$porcentaje_global);
            
        } else if(is_array($selectall) and !is_null($selectall)){
             $this->loadModel('extension/precio_manager');
            $this->model_extension_precio_manager->actualizarAllProducto($porcentaje);
        }
        redirect($this->html->getSecureURL('extension/precio_manager'));

    } 




  
 

 

}