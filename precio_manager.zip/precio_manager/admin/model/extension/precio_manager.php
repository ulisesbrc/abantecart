<?php
/*------------------------------------------------------------------------------
  $Id$

  AbanteCart, Ideal OpenSource Ecommerce Solution
  http://www.AbanteCart.com

  Copyright © 2011-2020 Belavier Commerce LLC

  This source file is subject to Open Software License (OSL 3.0)
  License details is bundled with this package in the file LICENSE.txt.
  It is also available at this URL:
  <http://www.opensource.org/licenses/OSL-3.0>

 UPGRADE NOTE:
   Do not edit or add to this file if you wish to upgrade AbanteCart to newer
   versions in the future. If you wish to customize AbanteCart for your
   needs please refer to http://www.AbanteCart.com for more information.
------------------------------------------------------------------------------*/
/**
 * Class ModelExtensionBannerManager
 */

/** @noinspection PhpUndefinedClassInspection */
class ModelExtensionPrecioManager extends Model
{
    /**
     * @param int $id
     *
     * @param float $porcentaje
     *
     */
    public function actualizarProducto($id=0,$porcentaje=0)
    {
        $sql = "UPDATE ".$this->db->table('products')." SET price=(price+(price*$porcentaje/100)) WHERE product_id=".$id;
        return $result = $this->db->query($sql);

    }
       /**
     * @param string $ids
     *
     * @param float $porcentaje
     *
     */
    public function actualizarArrayProducto($ids,$porcentaje=0)
    {   $porcentaje=floatval($porcentaje);
        $sql = "UPDATE ".$this->db->table('products')." SET price=(price+(price*$porcentaje/100)) WHERE product_id IN(".$ids.")";
        return $result = $this->db->query($sql);

    }
       /**
     * @param float $porcentaje
     *
     */
    public function actualizarAllProducto($porcentaje=0)
    {   $porcentaje=floatval($porcentaje);
        $sql = "UPDATE ".$this->db->table('products')." SET price=(price+(price*$porcentaje/100)) ";
        return $result = $this->db->query($sql);

    }
    public function getProduct(){
	 $language_id = $this->language->getContentLanguageID();
        $sql = "SELECT p.product_id,p.price,pd.name as nombre, p.model,p.price,m.object_id,m.resource_id,d.resource_path,d.name FROM ".$this->db->table('products')." as p LEFT JOIN  ".$this->db->table('product_descriptions')." as pd ON p.product_id=pd.product_id LEFT OUTER JOIN ".$this->db->table('resource_map')." as m ON (p.product_id=m.object_id AND pd.language_id = '".(int)$language_id."') LEFT OUTER JOIN ".$this->db->table('resource_descriptions')." as d ON d.resource_id=m.resource_id WHERE m.object_name='products' AND (m.sort_order=0 OR m.sort_order=1) GROUP BY p.product_id ORDER BY p.product_id ASC";
		
	$sql2 = "SELECT pd.product_id,pd.price,pd.name as nombre, rm.resource_id,pd.resource_path,pd.name	FROM ".$this->db->table("resource_map")." rm
					LEFT JOIN ".$this->db->table("product_descriptions")." pd
						ON ( rm.object_id = pd.product_id AND pd.language_id = '".(int)$language_id."')
					WHERE rm.resource_id = '".(int)$resource_id."'
						AND rm.object_name = 'products'";
						
    $result = $this->db->query($sql);

       if ($result->num_rows) {

        $datos = $result->rows;
        } else {
            $datos =array();
        }
        return $datos;
    }

}