<?php
/*------------------------------------------------------------------------------
  $Id$

  AbanteCart, Ideal OpenSource Ecommerce Solution
  http://www.AbanteCart.com

  Copyright © 2011-2020 Belavier Commerce LLC

  This source file is subject to Open Software License (OSL 3.0)
  Lincence details is bundled with this package in the file LICENSE.txt.
  It is also available at this URL:
  <http://www.opensource.org/licenses/OSL-3.0>

 UPGRADE NOTE:
   Do not edit or add to this file if you wish to upgrade AbanteCart to newer
   versions in the future. If you wish to customize AbanteCart for your
   needs please refer to http://www.AbanteCart.com for more information.
------------------------------------------------------------------------------*/
if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}

/**
 * @property ModelExtensionmercadopago $model_extension_mercadopago
 * @property ModelCheckoutOrder      $model_checkout_order
 */
class ControllerResponsesExtensionMercadopago extends AController
{
    public $data = array();

    public function main()
    {
        $this->loadLanguage('mercadopago/mercadopago');
        $this->data['button_confirm'] = $this->language->get('button_confirm');
        $this->data['button_back'] = $this->language->get('button_back');

        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        if ($this->config->get('mercadopago_test')) {
            $this->data['action'] = 'https://sandbox.mercadopago.com/checkout/purchase';
        } else {
            $this->data['action'] = 'https://www.mercadopago.com/checkout/purchase';
        }

        $this->data['sid'] = $this->config->get('mercadopago_account');
        $this->data['currency_code'] = $order_info['currency'];
        $this->data['total'] = $this->currency->format($order_info['total'], $order_info['currency'], $order_info['value'], false);
        $this->data['cart_order_id'] = $this->session->data['order_id'];
        $this->data['order_number'] = $this->session->data['order_id'];
        $this->data['card_holder_name'] = $order_info['payment_firstname'].' '.$order_info['payment_lastname'];
        $this->data['street_address'] = $order_info['payment_address_1'];
        $this->data['city'] = $order_info['payment_city'];
        $this->data['state'] = $order_info['payment_zone'];
        $this->data['zip'] = $order_info['payment_postcode'];
        $this->data['country'] = $order_info['payment_country'];
        $this->data['email'] = $order_info['email'];
        $this->data['phone'] = $order_info['telephone'];
        if ($order_info['shipping_lastname']) {
            $this->data['ship_name'] = $order_info['shipping_firstname'].' '.$order_info['shipping_lastname'];
        } else {
            $this->data['ship_name'] = $order_info['firstname'].' '.$order_info['lastname'];
        }
    
        //$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        if ($this->cart->hasShipping()) {
            $this->data['ship_street_address'] = $order_info['shipping_address_1'];
            $this->data['ship_city'] = $order_info['shipping_city'];
            $this->data['ship_state'] = $order_info['shipping_zone'];
            $this->data['ship_zip'] = $order_info['shipping_postcode'];
            $this->data['ship_country'] = $order_info['shipping_country'];
        } else {
            $this->data['ship_street_address'] = $order_info['payment_address_1'];
            $this->data['ship_city'] = $order_info['payment_city'];
            $this->data['ship_state'] = $order_info['payment_zone'];
            $this->data['ship_zip'] = $order_info['payment_postcode'];
            $this->data['ship_country'] = $order_info['payment_country'];
        }

        $this->data['products'] = array();
        $this->data['coupon_id'] = $order_info['coupon_id'];
        $this->load->model('extension/mercadopago');
        $this->data['descuento'] = $this->model_extension_mercadopago->getDescuento($this->data['coupon_id']);
       
        $products = $this->cart->getProducts();
        $subtotal="";
        $entro =0;
        $this->data['envio'] =$this->session->data['shipping_method']['cost'];
 
 $cant=0;
 $cantidad_productos = count($products);
        foreach ($products as $product) {
            $precio = $this->currency->format(
                    $product['price'],
                    $order_info['currency'],
                    $order_info['value'],
                    false
                );

            

            if($this->data['coupon_id'] ) {
              //SI ES FREE SHIPPING
                if($this->data['descuento']['shipping']) {
                     $this->data['envio'] =0;
                     $this->data['coupon_amount'] = $this->data['total'];
                }else{
                    if($this->data['descuento']['type']=="P"){ //porcentaje
                         $this->data['coupon_amount']=$precio*$this->data['descuento']['discount']/100;
                         $precio = $precio - $this->data['coupon_amount'];
                    }
                    if($this->data['descuento']['type']=="F"){ //FIX
                        if(!$entro){
                            if($this->data['descuento']['discount']<=  $this->data['envio']){
                                  $this->data['envio']= $this->data['envio']-$this->data['descuento']['discount'];
                                 $entro=1;
                            }
                        }
                    }  
                }
            }
            $free_shipping =  $product['free_shipping'];
            if($free_shipping){
                 $cant+=1;
            }
            if($cant == $cantidad_productos ){
                 $this->data['envio']=0;
            }
            $subtotal += $precio*$product['quantity'];
            $this->data['products'][] = array(
                'product_id'  => $product['product_id'],
                'name'        => $product['name'],
                'description' => $product['name'],
                'quantity'    => $product['quantity'],
                'price'       => $precio
            );
        }

        if ($this->config->get('mercadopago_test')) {
            $this->data['demo'] = 'Y';
        }

        $this->data['lang'] = $this->session->data['language'];

        if ($this->request->get['rt'] == 'checkout/guest_step_3') {
            $this->data['back'] = $this->html->getSecureURL('checkout/guest_step_2', '&mode=edit', true);
        } else {
            $this->data['back'] = $this->html->getSecureURL('checkout/payment', '&mode=edit', true);
        }
        
       
      //  var_dump( $this->data);
    // exit;
        $this->view->batchAssign($this->data);
        $this->processTemplate('responses/mercadopago.tpl');
     
    }
/*
    public function callback()
    {
        if ($this->request->is_GET()) {
            redirect($this->html->getNonSecureURL('index/home'));
        }
        $post = $this->request->post;
        // hash check
        if (!md5(
            $post['sale_id']
            .$this->config->get('mercadopago_account')
            .$post['invoice_id']
            .$this->config->get('mercadopago_secret')) == strtolower($post['md5_hash'])
        ){
            exit;
        }

        $this->load->model('checkout/order');

        $order_id = (int)$this->request->post['vendor_order_id'];
        $order_info = $this->model_checkout_order->getOrder($order_id);
        if (!$order_info) {
            return null;
        }
        $this->load->model('extension/mercadopago');
        if ($post['message_type'] == 'ORDER_CREATED') {
            $this->model_checkout_order->confirm(
                (int)$post['vendor_order_id'],
                $this->config->get('mercadopago_order_status_id')
            );
        } elseif ($post['message_type'] == 'REFUND_ISSUED') {
            $order_status_id = $this->model_extension_mercadopago->getOrderStatusIdByName('failed');
            $this->model_checkout_order->update(
                (int)$post['vendor_order_id'],
                $order_status_id,
                'Status changed by mercadopago INS'
            );
        } elseif ($post['message_type'] == 'FRAUD_STATUS_CHANGED' && $post['fraud_status'] == 'pass') {
            $order_status_id = $this->model_extension_mercadopago->getOrderStatusIdByName('processing');
            $this->model_checkout_order->update(
                (int)$post['vendor_order_id'],
                $order_status_id,
                'Status changed by mercadopago INS'
            );
        } elseif ($post['message_type'] == 'SHIP_STATUS_CHANGED' && $post['ship_status'] == 'shipped') {
            $order_status_id = $this->model_extension_mercadopago->getOrderStatusIdByName('complete');
            $this->model_checkout_order->update(
                (int)$post['vendor_order_id'],
                $order_status_id,
                'Status changed by mercadopago INS'
            );
        } else {
            redirect($this->html->getSecureURL('checkout/confirm'));
        }
    }

    public function pending_payment()
    {
        $this->addChild('common/head', 'head', 'common/head.tpl');
        $this->addChild('common/footer', 'footer', 'common/footer.tpl');
        $this->document->setTitle('waiting for payment');
        $this->view->assign('text_message', 'waiting for payment confirmation');
        $this->view->assign('text_redirecting', 'redirecting');
        $this->view->assign('test_url', $this->html->getSecureURL('r/extension/mercadopago/is_confirmed'));
        $this->view->assign('success_url', $this->html->getSecureURL('checkout/success'));
        $this->processTemplate('responses/pending_ipn.tpl');
    }
*/
    public function error()
    {$this->addChild('common/head', 'head', 'common/head.tpl');
        $this->addChild('common/footer', 'footer', 'common/footer.tpl');
        echo "<script>alert('Ha ocurrido un error')</scrip>";
        $this->processTemplate('home/pending_ipn.tpl');
        //redirect($this->html->getSecureURL('checkout/success'));
    }
    public function ipn()
    {   $token = $this->config->get('mercadopago_token');
        $post = $this->request->post;
        $this->load->model('checkout/order');
        header("HTTP/1.1 200 OK");
    $notifications=file_get_contents("php://input");
    //$get ='{"action":"payment.created","api_version":"v1","data":{"id":"29666823"},"date_created":"2020-09-11T05:51:18Z","id":6406512589,"live_mode":false,"type":"payment","user_id":"900650"}';
    $datos = json_decode($notifications);
        if(is_object($datos)){
            if($datos->action =='payment.created')
            {
                $id = $datos->data->id;
                if($id>0){
                    $url = "https://api.mercadopago.com/v1/payments/".$id."?access_token=$token";
                    $handle = curl_init($url);
                    curl_setopt($handle, CURLOPT_RETURNTRANSFER, 1 );
                    curl_setopt($handle, CURLOPT_URL, $url); 
                    $result = curl_exec($handle);
                    $result = json_decode($result);
                 
                    if($result->status == 'approved') {
                        $total_pagado= $result->transaction_details->total_paid_amount;
                        $id_order= $result->external_reference;
                        $order_status_id = $this->model_extension_mercadopago->getOrderStatusIdByName('completado');          
                        $total_order = $this->model_extension_mercadopago->getOrderMonto($id_order);
                        if($total_order ==$total_pagado)
                        {
                           // echo "actualizar";
                            $this->model_checkout_order->update(
                                (int)$result->external_reference,
                                $order_status_id,
                                'Estatus cambiado por mercadopago'
                            );
                        }
                    }
                }
                

            }
        }
    }
    public function confirm()
    {
        $this->load->model('checkout/order');
        $this->model_checkout_order->confirm($this->session->data['order_id'], $this->config->get('default_cod_order_status_id'));
    }
    public function mensaje()
    {   $urladicional ='';
        switch ($this->request->get['estado']) {
            case 'success':
                $this->data['mensaje'] =$this->config->get('mercadopago_msg_success');
                $urladicional = '/index.php?rt=checkout/success';
                break;
            case 'failure':
                $this->data['mensaje'] =$this->config->get('mercadopago_msg_failure');
                break;
            case 'pending':
                $this->data['mensaje'] =$this->config->get('mercadopago_msg_pending');
                break;
            default:
                $this->data['mensaje'] ="";
                break;
        }     
        $this->view->batchAssign($this->data);
        $url = ($this->config->get('mercadopago_url'))?$this->config->get('mercadopago_url'):"https://dominio.com"; 
          //$patrón = '/<body class="home">/i';

        $alert = ($this->data['mensaje'])?"alert('".$this->data['mensaje']."');":"";
        if($urladicional){
            $alert = "";
            $url = $this->config->get('mercadopago_url'); 
            $url .=$urladicional;
        }
        $sustitución = "<body><script>
        function load() {
       $alert
       window.location = '$url'
      }
      window.onload = load;
      </script>";
      echo "<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
    <title></title>
</head>
$sustitución</body>
</html>";
      //echo $url."/";
      //echo $result;
      //echo preg_replace($patrón, $sustitución, $cadena);
        //echo $result;
        //$this->processTemplate('responses/aviso.tpl');
    }
}