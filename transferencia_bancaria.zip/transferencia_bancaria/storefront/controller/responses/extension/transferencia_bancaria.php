<?php
/*------------------------------------------------------------------------------
  $Id$

  AbanteCart, Ideal OpenSource Ecommerce Solution
  http://www.AbanteCart.com

  Copyright © 2011-2020 Belavier Commerce LLC

  This source file is subject to Open Software License (OSL 3.0)
  Lincence details is bundled with this package in the file LICENSE.txt.
  It is also available at this URL:
  <http://www.opensource.org/licenses/OSL-3.0>

 UPGRADE NOTE:
   Do not edit or add to this file if you wish to upgrade AbanteCart to newer
   versions in the future. If you wish to customize AbanteCart for your
   needs please refer to http://www.AbanteCart.com for more information.
------------------------------------------------------------------------------*/
if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}

class ControllerResponsesExtensionTransferenciaBancaria extends AController
{
    public function main()
    {
        $this->loadLanguage('transferencia_bancaria/transferencia_bancaria');

        $this->view->assign('text_instructions', $this->language->get('text_instructions'));
        $this->view->assign('text_payment', $this->language->get('text_payment'));

        $this->view->batchAssign($this->language->getASet());
        $lang_id = $this->language->getLanguageID();
        $instructions = $this->config->get('transferencia_bancaria_front');

        if (!$instructions) {
            $this->messages->saveError('transferencia_bancaria error', 'Please, set instructions for all languages!');
            $lang_id = $this->language->getDefaultLanguageID();
            $instructions = $this->config->get('transferencia_bancaria_front');
        }

        if (!$instructions) {
            $this->messages->saveError('transferencia_bancaria error', 'Please, set instructions for all languages!');
        }

        $this->view->assign('instructions', nl2br($instructions));
        $this->view->assign('continue', $this->html->getSecureURL('checkout/success'));

        if ($this->request->get['rt'] == 'checkout/guest_step_3') {
            $this->view->assign('back', $this->html->getSecureURL('checkout/guest_step_2', '&mode=edit', true));
        } else {
            $this->view->assign('back', $this->html->getSecureURL('checkout/payment', '', true));
        }

        //check total for to meat min requirement 
        if (has_value($this->config->get('transferencia_bancaria_order_min'))) {
            if ($this->cart->getTotal() < $this->config->get('transferencia_bancaria_order_min')) {
                $this->view->assign('minimum_notmet', $this->language->get('text_minimum_notmet'));
            }
        }

        $this->processTemplate('responses/transferencia_bancaria.tpl');
    }

    public function confirm()
    {
        $this->loadLanguage('transferencia_bancaria/transferencia_bancaria');
        $this->load->model('checkout/order');

        $comment = $this->language->get('text_instructions')."\n";
        $comment .= $this->config->get('transferencia_bancaria_front')."\n\n";
        $comment .= $this->language->get('text_payment')."\n";
        $comment = html_entity_decode($comment,ENT_QUOTES,'UTF-8');
        $email =html_entity_decode($this->config->get('transferencia_bancaria_email'),ENT_QUOTES,'UTF-8');
        $subject = $this->config->get('transferencia_bancaria_subject');
        $body = html_entity_decode($this->config->get('transferencia_bancaria_body'),ENT_QUOTES,'UTF-8');
        
        
        $order_id=$this->session->data['order_id'];
        $this->model_checkout_order->confirm($order_id, $this->config->get('transferencia_bancaria_order_status_id'), $comment);
        $query = $this->db->query("SELECT * FROM ".$this->db->table("orders")." WHERE order_id = '".(int)$order_id."'");
        if($query->num_rows){
          $total = number_format($query->row['total'],2);
          $patrones = array();
          $patrones[0] = '/#id/';
          $patrones[1] = '/#nombre/';
          $patrones[2] = '/#apellido/';
          $patrones[3] = '/#monto/';
          $sustituciones = array();
          $sustituciones[0] = $order_id;
          $sustituciones[1] = $query->row['firstname'];
          $sustituciones[2] = $query->row['lastname'];
          $sustituciones[3] = $total;
          $subject= preg_replace($patrones, $sustituciones, $subject);
          $body= preg_replace($patrones, $sustituciones, $body);
          $cabeceras  = 'MIME-Version: 1.0' . "\r\n";
          $cabeceras .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
          $cabeceras .= $email. "\r\n";
          @mail($query->row['email'], $subject,$body,$cabeceras);
        }

    }
}

