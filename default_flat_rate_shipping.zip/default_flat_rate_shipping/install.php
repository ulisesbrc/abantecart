<?php

if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}

$sql = "ALTER TABLE `".$this->db->table('zones')."` ADD `costo` INT(4) NOT NULL AFTER `sort_order`; ";
$result = $this->db->query($sql);