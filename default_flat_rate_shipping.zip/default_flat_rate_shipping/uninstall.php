<?php

if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}
 
$sql = "ALTER TABLE `".$this->db->table('zones')."` DROP `costo`;";
$result = $this->db->query($sql);