<?php
/*------------------------------------------------------------------------------
  $Id$

  AbanteCart, Ideal OpenSource Ecommerce Solution
  http://www.AbanteCart.com

  Copyright © 2011-2020 Belavier Commerce LLC

  This source file is subject to Open Software License (OSL 3.0)
  Lincence details is bundled with this package in the file LICENSE.txt.
  It is also available at this URL:
  <http://www.opensource.org/licenses/OSL-3.0>

 UPGRADE NOTE:
   Do not edit or add to this file if you wish to upgrade AbanteCart to newer
   versions in the future. If you wish to customize AbanteCart for your
   needs please refer to http://www.AbanteCart.com for more information.
------------------------------------------------------------------------------*/
if (!defined('DIR_CORE')) {
    header('Location: static_pages/');
}

class ControllerResponsesExtensionPaypal extends AController
{  public $data = array();
      private $use_sandbox = true;
    /** @var bool Indicates if the local certificates are used. */
    private $use_local_certs = true;

    /** Production Postback URL */
    const VERIFY_URI = 'https://ipnpb.paypal.com/cgi-bin/webscr';
    /** Sandbox Postback URL */
    const SANDBOX_VERIFY_URI = 'https://ipnpb.sandbox.paypal.com/cgi-bin/webscr';

    /** Response from PayPal indicating validation was successful */
    const VALID = 'VERIFIED';
    /** Response from PayPal indicating validation failed */
    const INVALID = 'INVALID';

    /**
     * Sets the IPN verification to sandbox mode (for use when testing,
     * should not be enabled in production).
     * @return void
     */
    public function useSandbox()
    {
        $this->use_sandbox = true;
    }

    /**
     * Sets curl to use php curl's built in certs (may be required in some
     * environments).
     * @return void
     */
    public function usePHPCerts()
    {
        $this->use_local_certs = false;
    }

    /**
     * Determine endpoint to post the verification data to.
     *
     * @return string
     */
    public function getPaypalUri()
    {
       if ($this->config->get('paypal_test')) {
            return self::VERIFY_URI;
        } else {
             return self::SANDBOX_VERIFY_URI;
        }
    }

    public function main()
    {
        $this->loadLanguage('paypal/paypal');

        $this->view->assign('text_instructions', $this->language->get('text_instructions'));
        $this->view->assign('text_payment', $this->language->get('text_payment'));

        $this->view->batchAssign($this->language->getASet());
        $lang_id = $this->language->getLanguageID();
        $instructions = $this->config->get('paypal_front');

        if (!$instructions) {
            $this->messages->saveError('paypal error', 'Please, set instructions for all languages!');
            $lang_id = $this->language->getDefaultLanguageID();
            $instructions = $this->config->get('paypal_front');
        }

        if (!$instructions) {
            $this->messages->saveError('paypal error', 'Please, set instructions for all languages!');
        }

        $this->view->assign('instructions', nl2br($instructions));

        $this->view->assign('continue', $this->html->getSecureURL('checkout/success'));

        if ($this->request->get['rt'] == 'checkout/guest_step_3') {
            $this->view->assign('back', $this->html->getSecureURL('checkout/guest_step_2', '&mode=edit', true));
        } else {
            $this->view->assign('back', $this->html->getSecureURL('checkout/payment', '', true));
        }

        //check total for to meat min requirement 
        if (has_value($this->config->get('paypal_order_min'))) {
            if ($this->cart->getTotal() < $this->config->get('paypal_order_min')) {
                $this->view->assign('minimum_notmet', $this->language->get('text_minimum_notmet'));
            }
        }
        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        if ($this->config->get('paypal_test')) {
            $this->data['action'] = 'https://api.paypal.com';
        } else {
            $this->data['action'] = 'https://api.sandbox.paypal.com';
        }

        $this->data['sid'] = $this->config->get('paypal_account');
        $this->data['currency_code'] = $order_info['currency'];
        $this->data['total'] = $this->currency->format($order_info['total'], $order_info['currency'], $order_info['value'], false);
        $this->data['cart_order_id'] = $this->session->data['order_id'];
        $this->data['order_number'] = $this->session->data['order_id'];
        $this->data['card_holder_name'] = $order_info['payment_firstname'].' '.$order_info['payment_lastname'];
        $this->data['street_address'] = $order_info['payment_address_1'];
        $this->data['city'] = $order_info['payment_city'];
        $this->data['state'] = $order_info['payment_zone'];
        $this->data['zip'] = $order_info['payment_postcode'];
        $this->data['country'] = $order_info['payment_country'];
        $this->data['email'] = $order_info['email'];
        $this->data['phone'] = $order_info['telephone'];
        if ($order_info['shipping_lastname']) {
            $this->data['ship_name'] = $order_info['shipping_firstname'].' '.$order_info['shipping_lastname'];
        } else {
            $this->data['ship_name'] = $order_info['firstname'].' '.$order_info['lastname'];
        }
    
        //$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        if ($this->cart->hasShipping()) {
            $this->data['ship_street_address'] = $order_info['shipping_address_1'];
            $this->data['ship_city'] = $order_info['shipping_city'];
            $this->data['ship_state'] = $order_info['shipping_zone'];
            $this->data['ship_zip'] = $order_info['shipping_postcode'];
            $this->data['ship_country'] = $order_info['shipping_country'];
        } else {
            $this->data['ship_street_address'] = $order_info['payment_address_1'];
            $this->data['ship_city'] = $order_info['payment_city'];
            $this->data['ship_state'] = $order_info['payment_zone'];
            $this->data['ship_zip'] = $order_info['payment_postcode'];
            $this->data['ship_country'] = $order_info['payment_country'];
        }

        $this->data['products'] = array();
        $this->data['coupon_id'] = $order_info['coupon_id'];
        $this->load->model('extension/paypal');
        $this->data['descuento'] = $this->model_extension_paypal->getDescuento($this->data['coupon_id']);
       
        $products = $this->cart->getProducts();
        $subtotal="";
        $entro =0;
        $this->data['envio'] =$this->session->data['shipping_method']['cost'];
 
 $cant=0;
 $cantidad_productos = count($products);
        foreach ($products as $product) {
            $precio = $this->currency->format(
                    $product['price'],
                    $order_info['currency'],
                    $order_info['value'],
                    false
                );

            

            if($this->data['coupon_id'] ) {
              //SI ES FREE SHIPPING
                if($this->data['descuento']['shipping']) {
                     $this->data['envio'] =0;
                     $this->data['coupon_amount'] = $this->data['total'];
                }else{
                    if($this->data['descuento']['type']=="P"){ //porcentaje
                         $this->data['coupon_amount']=$precio*$this->data['descuento']['discount']/100;
                         $precio = $precio - $this->data['coupon_amount'];
                    }
                    if($this->data['descuento']['type']=="F"){ //FIX
                        if(!$entro){
                            if($this->data['descuento']['discount']<=  $this->data['envio']){
                                  $this->data['envio']= $this->data['envio']-$this->data['descuento']['discount'];
                                 $entro=1;
                            }
                        }
                    }  
                }
            }
            $free_shipping =  $product['free_shipping'];
            if($free_shipping){
                 $cant+=1;
            }
            if($cant == $cantidad_productos ){
                 $this->data['envio']=0;
            }
            $subtotal += $precio*$product['quantity'];
            $this->data['products'][] = array(
                'product_id'  => $product['product_id'],
                'name'        => $product['name'],
                'description' => $product['name'],
                'quantity'    => $product['quantity'],
                'price'       => $precio
            );
        }

        if ($this->config->get('paypal_test')) {
            $this->data['demo'] = 'Y';
        }

        $this->data['lang'] = $this->session->data['language'];

        if ($this->request->get['rt'] == 'checkout/guest_step_3') {
            $this->data['back'] = $this->html->getSecureURL('checkout/guest_step_2', '&mode=edit', true);
        } else {
            $this->data['back'] = $this->html->getSecureURL('checkout/payment', '&mode=edit', true);
        }
        
       
      //  var_dump( $this->data);
    // exit;
        $this->view->batchAssign($this->data);

        $this->processTemplate('responses/paypal.tpl');
    }

    public function confirm()
    {
        $this->loadLanguage('paypal/paypal');
        $this->load->model('checkout/order');

        $comment = $this->language->get('text_instructions')."\n";
        $comment .= $this->config->get('paypal_front')."\n\n";
        $comment .= $this->language->get('text_payment')."\n";
        $comment = html_entity_decode($comment,ENT_QUOTES,'UTF-8');
        $email =html_entity_decode($this->config->get('paypal_email'),ENT_QUOTES,'UTF-8');
        $subject = $this->config->get('paypal_subject');
        $body = html_entity_decode($this->config->get('paypal_body'),ENT_QUOTES,'UTF-8');
        
        
        $order_id=$this->session->data['order_id'];
        $this->model_checkout_order->confirm($order_id, $this->config->get('paypal_order_status_id'), $comment);
        $query = $this->db->query("SELECT * FROM ".$this->db->table("orders")." WHERE order_id = '".(int)$order_id."'");
    }
    public function ipn()
    {   $token = $this->config->get('paypal_token');
        $post = $this->request->post;
        $this->load->model('checkout/order');
        header("HTTP/1.1 200 OK");
          $raw_post_data = file_get_contents('php://input');
          $raw_post_array = explode('&', $raw_post_data);
    
          $myPost = array();
          foreach ($raw_post_array as $keyval) {
              $keyval = explode('=', $keyval);
              if (count($keyval) == 2) {
                  // Since we do not want the plus in the datetime string to be encoded to a space, we manually encode it.
                  if ($keyval[0] === 'payment_date') {
                      if (substr_count($keyval[1], '+') === 1) {
                          $keyval[1] = str_replace('+', '%2B', $keyval[1]);
                      }
                  }
                  $myPost[$keyval[0]] = urldecode($keyval[1]);
              }
          }

          // Build the body of the verification post request, adding the _notify-validate command.
          $req = 'cmd=_notify-validate';
          $get_magic_quotes_exists = false;
          if (function_exists('get_magic_quotes_gpc')) {
              $get_magic_quotes_exists = true;
          }
          foreach ($myPost as $key => $value) {
              if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                  $value = urlencode(stripslashes($value));
              } else {
                  $value = urlencode($value);
              }
              $req .= "&$key=$value";
          }

          // Post the data back to PayPal, using curl. Throw exceptions if errors occur.
          $ch = curl_init($this->getPaypalUri());
          curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
          curl_setopt($ch, CURLOPT_POST, 1);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
          curl_setopt($ch, CURLOPT_SSLVERSION, 6);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

          // This is often required if the server is missing a global cert bundle, or is using an outdated one.
          if ($this->use_local_certs) {
              curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . "/cert/cacert.pem");
          }
          curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
          curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
              'User-Agent: PHP-IPN-Verification-Script',
              'Connection: Close',
          ));
          $res = curl_exec($ch);
          if ( ! ($res)) {
              $errno = curl_errno($ch);
              $errstr = curl_error($ch);
              curl_close($ch);
              throw new Exception("cURL error: [$errno] $errstr");
          }

          $info = curl_getinfo($ch);
          $http_code = $info['http_code'];
          if ($http_code != 200) {
              throw new Exception("PayPal responded with http code $http_code");
          }

          curl_close($ch);

          // Check if PayPal verifies the IPN data, and if so, return true.
          if ($res == self::VALID) {
             if ($_POST["payment_status"] == "Completed" and $_POST["mc_currency"] =="USD") {
                        $total_pagado= $_POST["mc_gross"];
                        $id_order= $_POST["custom"];;
                        $order_status_id = $this->model_extension_paypal->getOrderStatusIdByName('completado');          
                        $total_order = $this->model_extension_paypal->getOrderMonto($id_order);
                        $cotizacion_dolar = $this->config->get('cotizacion_dolar');
                        $cotizacion_dolar =($cotizacion_dolar)?$cotizacion_dolar:1;
                        $total_order = $total_order/$cotizacion_dolar;
                        
                        if($total_order <= $total_pagado)
                        {
                           // echo "actualizar";
                            $this->model_checkout_order->update(
                                (int)$id_order,
                                $order_status_id,
                                'Estatus cambiado por paypal'
                            );
                        }
              }
          }
       
    
    }
    public function mensaje()
    {  
        switch ($this->request->get['estado']) {
            case 'cancel':
                $this->data['mensaje'] =$this->config->get('paypal_msg_cancel');
                break;
            default:
                $this->data['mensaje'] ="";
                break;
        }     
        $this->view->batchAssign($this->data);
        $url = ($this->config->get('paypal_url'))?$this->config->get('paypal_url'):"https://dominio.com"; 
          //$patrón = '/<body class="home">/i';

        $alert = ($this->data['mensaje'])?"alert('".$this->data['mensaje']."');":"";
   
        $sustitución = "<body><script>
        function load() {
       $alert
       window.location = '$url'
      }
      window.onload = load;
      </script>";
      echo "<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
    <title></title>
</head>
$sustitución</body>
</html>";

    }
}

